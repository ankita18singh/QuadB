// config/cloudinary.js
const cloudinary = require('cloudinary').v2;

cloudinary.config({
  cloud_name: "dwwehu5do",
  api_key: 867439499374638,
  api_secret: "0GR4nuWK8wANh91s6JEyd2hBnwc"
});

module.exports = cloudinary;